Stages:
1. UFO
2. SFD
3. TTF